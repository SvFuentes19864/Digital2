/*IE2023 ELECTRÓNICA DIGITAL 2
 * Author: SHAGTY VALERIA FUENTES GARCÍA
 * Carnet: 19864
 * Proyecto: POSTLAB 2
 * Hardware: PIC16F887
 * Created on 20 de julio de 2023 */

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

//******************************************************************************
//Librerías
//******************************************************************************

#include <xc.h>
#include <pic16f887.h>
#include <stdint.h>
#include <stdio.h>
#include "Oscilador.h"
#include "Config_ADC.h"
#include "LCD_8.h"
#include "UART.h"

//******************************************************************************
// Variables
//******************************************************************************

#define _XTAL_FREQ 4000000

unsigned int a;
long valor_adc;

char c;
char menuMostrado = 0;
char opcionSeleccionada = 0;
int adcValue;

uint8_t        UNI;                            // UNIDADES DE LOS DISPLAYS
uint8_t        DEC;                            // DECENAS DE LOS DISPLAYS
uint8_t        CEN;                            // CENTENAS DE LOS DISPLAYS
uint8_t        buffer[2];

//******************************************************************************
// Prototipos de funiones
//******************************************************************************

void setup();

//******************************************************************************
// Interrupciones
//******************************************************************************

void __interrupt() isr (void){

    if (PIR1bits.RCIF) {
        // Lee el carácter recibido
        c = RX_resultado();
        PIR1bits.RCIF = 0;
    }
}
//******************************************************************************
// Código principal
//******************************************************************************

int map(int input, int in_min, int in_max, long out_min, long out_max) {
  int output = (input - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
  return output;
}

void main(void) {
    
    setup();
    
    while(1){
     
// Parte del UART

    if (!menuMostrado) {
            // Muestra el menú si no se ha mostrado antes
            cadena("Ingrese el caracter que necesite: \r\n1. Leer potenciometro \r\n+ Aumentar contador \r\n- Decrementar contador \r\n");
            menuMostrado = 1;
        }
    
    if (c == 49){
    
        // Iniciar la conversión ADC
        ADCON0bits.GO = 1;
        // Esperar a que la conversión ADC termine
        while (ADCON0bits.GO);
        // Leer el valor convertido del ADC
        adcValue = adc_read();
        adcValue = map(adcValue, 0, 255, 0, 500);
        // Enviar el valor convertido a través del puerto serial
        char adcValueStr[4];                    // Se crea una cadena de 4 caracteres
        sprintf(adcValueStr, "%d", adcValue);   // función que convierte el valor entero a una cadena de caracteres
        enter();
        cadena("Valor del potenciometro: ");    // Se llama a la función
        cadena(adcValueStr);
        enter();
        TX_usart('\r');
        TX_usart('\n');
        // Deshabilitar el módulo ADC
        ADCON0bits.ADON = 0;
        
        // Reiniciar variables
        menuMostrado = 0;
        c = 0;
    
    }
    
    if (c == 43){
    
        PORTC++;
        
        enter();
        cadena("Has aumentado en 1 el contador de 4 bits");
        enter();
        enter();
        
        // Reiniciar variables
        menuMostrado = 0;
        c = 0;
    
    }
    
    if (c == 45){
    
        PORTC--;
        
        enter();
        cadena("Has decrementado en 1 el contador de 4 bits");
        enter();
        enter();
        
        // Reiniciar variables
        menuMostrado = 0;
        c = 0;
    
    }
        
// Parte del LCD
    
    valor_adc = adc_read();
    valor_adc = map(valor_adc, 0, 255, 0, 500);
        
    UNI = valor_adc % 10;          // Función para obtener las unidades
    DEC = (valor_adc / 10) % 10;   // Función para obtener las decenas
    CEN = (valor_adc / 100) % 10;  // Función para obtener las centenas
        
    Lcd_Clear();
    Lcd_Set_Cursor(1,1);
    Lcd_Write_String("Voltaje:");
    Lcd_Set_Cursor(2,1);
    sprintf(buffer, "%d", CEN);
    Lcd_Write_Char(buffer[0]);
    Lcd_Write_Char('.');
    sprintf(buffer, "%d", DEC);
    Lcd_Write_Char(buffer[0]);
    sprintf(buffer, "%d", UNI);
    Lcd_Write_Char(buffer[0]);
    __delay_ms(2000);
    
  }
}

//******************************************************************************
// Subrutines/funciones
//******************************************************************************

void setup(){
    
    configOsc(4);
    
//________________________CONFIGURACIÓN DE PUERTOS______________________________
    
    ANSEL = 0;
    ANSELH = 0;
    
    TRISD = 0;
    PORTD = 0;
    TRISC = 0b10000000;
    PORTC = 0;
    PORTB = 0;
    TRISB = 0;
    
//_______________________CONFIGURACIÓN DE PULLUPS_______________________________    
    
    OPTION_REGbits.nRBPU = 0;           // Habilita las resistencias pull-up internas
    
    WPUBbits.WPUB0 = 1;                 // Habilita la resistencia pull-up en puerto B
    WPUBbits.WPUB1 = 1;                 // Habilita la resistencia pull-up en puerto B
    
//__________________________CONFIGURACIÓN DE ADC________________________________
    
    adc_init(0);
    
//________________________CONFIGURACIÓN DEL LCD_________________________________
    
    Lcd_Init();
    
//________________________CONFIGURACIÓN DEL UART________________________________
    
    USART_setup(25);

}
