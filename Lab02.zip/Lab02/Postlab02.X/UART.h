#ifndef UART_H
#define	UART_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h>

//Prototipos
void USART_setup(int baudrate);
void cadena (char *str);
void TX_usart(char data);
char RX_resultado();
void enter();

#endif	/* UART_H */