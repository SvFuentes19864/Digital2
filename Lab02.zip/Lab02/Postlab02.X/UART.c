#include <xc.h>
#include "UART.h"
#include <stdlib.h>
#include <stdio.h>
#include <pic16f887.h>

#define _XTAL_FREQ 4000000

void USART_setup(int baudrate){
    TXSTAbits.SYNC = 0;         // ASÍNCRONO
    TXSTAbits.BRGH = 1;         // BAUD ALTA VELOCIDAD
    BAUDCTLbits.BRG16 = 0;      // 8 BITS REGISTRO
    
    SPBRG = baudrate;                 // BAUDAJE 9600
    SPBRGH = 0;                 
    
    RCSTAbits.SPEN = 1;         // HABILITAMOS LA COMUNICACIÓN SERIAL
    TXSTAbits.TX9 = 0;          // 8 BITS
    TXSTAbits.TXEN = 1;         // HABILITAMOS LA TRANSMISIÓN DE DATOS
    RCSTAbits.CREN = 1;         // HABILITAMOS LA RECEPCIÓN DE DATOS
    
    PIE1bits.RCIE = 1;          // Int. UART
    PIR1bits.RCIF = 1;
    
    INTCONbits.GIE = 1;         // Int. globales
    INTCONbits.PEIE = 1;        // Int. periféricos
}
void cadena (char *str){
        while(*str != '\0'){
            TX_usart(*str);
            str++;
        }
    }

void TX_usart(char data)
    {
    // Espera hasta que el registro de transmisión esté vacío
    while(!TXIF);
    // Envía el carácter a través del puerto serial
    TXREG = data;
    }
char RX_resultado()
    {
        return RCREG;
    }

void enter(){

    TX_usart('\r');
    TX_usart('\n');

}